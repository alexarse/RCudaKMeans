#include "RUtils.h"


namespace R
{
	void Print()
	{
		std::cout << std::endl;
	}
}
